export class Customer {
    id: number;
    name: string;
    age: number;
    active: boolean;
}

export class SearchItem {
    //searchString : string;
    constructor(private searchString:string){
        
    }
}

export class Item {
    itemId : number;
    sellerId : number;
    category:number;
    subcategory:number;
    itemCost:number;
    itemName:string;
    itemDescription:string;
    itemStockNumber:number;
    itemRemarks:string;
} 
