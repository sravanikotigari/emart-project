package com.sellerservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
 
import com.sellerservice.entity.Seller;
import com.sellerservice.entity.Category;
import com.sellerservice.entity.SubCategory;
@Repository
public interface SellerDao extends JpaRepository<Seller, Integer> {
	
	

//	Seller findOne(int id);

//	Seller findOne(int sellerid);

}
