package com.sellerservice;

import java.util.List;

import org.eclipse.jdt.internal.compiler.env.IModule.IService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sellerservice.entity.Items;
import com.sellerservice.entity.Seller;
import com.sellerservice.service.Iseller;


@RestController
public class ItemsController {
	
	@Autowired
	private Iseller service;
	
	@RequestMapping("/getAllItems") 
	public List<Items> getAllItems() 
    {
		  return service.getAllItems(); 
    } 
	
	@RequestMapping(value="/Add/items" , method=RequestMethod.POST)
	public Items add(@RequestBody Items items) 
	{
		return service.addItems(items);
	}
		
	@RequestMapping(value="/getItem/{id}" , method=RequestMethod.GET)
	public Items getProduct(@PathVariable("id") int id) {
		return service.getProduct(id);
	}
	
	@RequestMapping(value="/update/Items/{id}",method=RequestMethod.PUT)
	public Items updateSeller(@RequestBody Items items,@PathVariable("id") int id) 
	{
		return service.updateItems(items,id);
	}
	@DeleteMapping(value="/delete/{id}")
	public void deleteById(@PathVariable("id") int itemId) {
		service.deleteById(itemId);
	}
}
