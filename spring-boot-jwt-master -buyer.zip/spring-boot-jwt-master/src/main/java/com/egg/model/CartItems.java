package com.egg.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.springframework.boot.autoconfigure.web.ResourceProperties.Strategy;

@Entity
public class CartItems {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cartItemId;
	private int itemId;
	private int quantity;
	private float price;
	@ManyToOne
	private BuyerDetails buyerDetailsId;
	public CartItems() 
	{ 
		
	}
	public CartItems(int cartItemId, int itemId, int quantity, BuyerDetails buyerDetails) {
		super();
		this.cartItemId = cartItemId;
		this.itemId = itemId;
		this.quantity = quantity;
		this.price=price;
		this.buyerDetailsId = buyerDetailsId;
	}
	public int getCartItemId() {
		return cartItemId;
	}
	public void setCartItemId(int cartItemId) {
		this.cartItemId = cartItemId;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public BuyerDetails getBuyerDetailsId() {
		return buyerDetailsId;
	}
	public void setBuyerDetailsId(BuyerDetails buyerDetailsId) {
		this.buyerDetailsId = buyerDetailsId;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "CartItems [cartItemId=" + cartItemId + ", itemId=" + itemId + ", quantity=" + quantity + ", price="
				+ price + ", buyerDetailsId=" + buyerDetailsId + "]";
	}
	

}
