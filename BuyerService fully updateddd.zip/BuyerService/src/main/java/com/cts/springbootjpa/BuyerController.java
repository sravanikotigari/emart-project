package com.cts.springbootjpa;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.springbootjpa.entity.BuyerDetails;
import com.cts.springbootjpa.entity.CartItems;
import com.cts.springbootjpa.entity.Category;
import com.cts.springbootjpa.entity.PurchaseHistory;
import com.cts.springbootjpa.entity.Sub_Category;
import com.cts.springbootjpa.entity.TransactionHistory;
import com.cts.springbootjpa.service.Iservice;


@RestController
public class BuyerController {
	@Autowired
	private Iservice service;

	//Buyers
    @RequestMapping("/getAll") public List<BuyerDetails> getAll() 
    {
		  return service.getAll(); 
    } 
	@RequestMapping(value="/Add/buyer",method=RequestMethod.POST)
	public BuyerDetails add(@RequestBody BuyerDetails buyerdetails) 
	{
		return service.add(buyerdetails);
	}
	@RequestMapping(value="/getUser/{ids}",method=RequestMethod.GET)
	public BuyerDetails getUser(@PathVariable("ids") int id) 
	{
		return service.getUser(id);
	}
	@RequestMapping(value="/update/buyer/{ids}",method=RequestMethod.PUT)
	public BuyerDetails updateBuyer(@RequestBody BuyerDetails buyerdetails,@PathVariable("ids") int id) 
	{
		return service.updateBuyer(buyerdetails,id);
	}
	

}
